package com.example.diancai;
import java.util.ArrayList;
import java.util.List;

import android.app.Activity;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.graphics.BitmapFactory;
import android.graphics.Matrix;
import android.os.Bundle;
import android.os.Parcelable;
import android.support.v4.view.PagerAdapter;
import android.support.v4.view.ViewPager;
import android.support.v4.view.ViewPager.OnPageChangeListener;
import android.util.DisplayMetrics;
import android.view.LayoutInflater;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.View.OnClickListener;
import android.view.View.OnTouchListener;
import android.view.animation.Animation;
import android.view.animation.TranslateAnimation;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.BaseAdapter;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import com.example.DBHelper.SQLiteDbHelper;
import com.example.adapter.MyListViewAdapter;
import com.example.adapter.YidianListViewAdapter;
import com.example.adapter.YidianListViewAdapter.ViewHolder;

/**
 * Tab页面手势滑动切换以及动画效果
 * 
 * @author HWM
 * 
 */
public class YidianActivity extends Activity {
	// ViewPager是google SDk中自带的一个附加包的一个类，可以用来实现屏幕间的切换。
	// android-support-v4.jar
	//文件的路径
	public final static String URL = "/data/data/com.example.diancai/files";
	//数据库文件
	public final static String DB_FILE_NAME = "tabkaway.db";
	// 归属地
	public final static String TABLE_NAME = "insert_dish";
	YidianListViewAdapter adapter;
	static SQLiteDatabase db = null;
	private ListView myList1;
	Cursor cs;
	ImageView imageView1;
	private TextView text_yidian;
	private List<String> list1,list2,list3,list5;
	private List<Integer> list4;
	@Override
	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.yidiancai);
		myList1= (ListView)findViewById(R.id.yidianlist);
		text_yidian = (TextView)findViewById(R.id.yidianprice1);
		getlls1();
	    adapter = new YidianListViewAdapter(this,getlls1(),list1,list2,list3,list4,list5);
		myList1.setAdapter(adapter);
		System.out.println(">>>>>>>>   onCreate");
		//adapter.notifyDataSetChanged();
		myList1.setOnItemClickListener(new OnItemClickListener() {
			public void onItemClick(AdapterView<?> arg0, View arg1, int arg2,
					long arg3) {
				// TODO Auto-generated method stub
				//Toast.makeText(YidianActivity.this, "点击事件还未添加！", Toast.LENGTH_SHORT).show();
//				adapter.notifyDataSetChanged();
				getlls1();
				adapter.notifyDataSetChanged();
			}

		});
	}

	
//	@Override
//	protected void onResume() {
//		// TODO Auto-generated method stub
//		super.onResume();
//		getlls1();
//		adapter.notifyDataSetChanged();
//		
//	}
//	@Override
//	protected void onStop() {
//		// TODO Auto-generated method stub
//		super.onStop();
//		getlls1();
//		adapter.notifyDataSetChanged();
//	}
//	@Override
//	protected void onPause() {
//		// TODO Auto-generated method stub
//		super.onPause();
//		getlls1();
//		adapter.notifyDataSetChanged();
//	}


	public  List<List<String>> getlls1() {  
		List<List<String>> lls = new ArrayList<List<String>>();
		list1 = new ArrayList<String>();  
		list2 = new ArrayList<String>(); 
		list3 = new ArrayList<String>(); 
		list4 = new ArrayList<Integer>(); 
		list5 = new ArrayList<String>();
		float a=0;
		db=SQLiteDbHelper.copyDB((this));
		String sql = "SELECT * FROM "+TABLE_NAME;
		cs = db.rawQuery(sql, null);  
		if(cs.moveToFirst()) {  
			do{     
				String je = cs.getString(cs.getColumnIndex("Name"));  
				String ms = cs.getString(cs.getColumnIndex("Info")); 
				String lx = cs.getString(cs.getColumnIndex("Price"));  
				String sj = cs.getString(cs.getColumnIndex("Time"));
				String im = cs.getString(cs.getColumnIndex("Images"));
				int i = Integer.valueOf(im);
				list1.add(je);   
				list2.add(ms);
				list3.add(lx);
				list5.add(sj);
				list4.add(i);   
				lls.add(list1);	
				lls.add(list2);	
				lls.add(list3);	
				lls.add(list5);	

			}    
			while(cs.moveToNext());
		}      
		for(int i=0;i<list3.size();i++){
			float m =Float.valueOf(list3.get(i));
			a = a+m;
		}
		text_yidian.setText(a+"");
		cs.close();   
		db.close();  
		//adapter.notifyDataSetChanged();
		return lls; 
	}	
	public class YidianListViewAdapter extends BaseAdapter{
		
		public final class ViewHolder{
			public ImageView img;
			public Button btn_diancai;
			TextView tv1, tv2, tv3, tv4;

		}
		
		Cursor cs;
		private List<List<String>> lls;
		private LayoutInflater mInflater;
		private List<String> list1,list2,list3,list5;
		private List<Integer> list4;
		// 归属地
		//public final static String TABLE_NAME = "dish_info";
		private Integer[] mImageIds = {
				R.drawable.images_1,		   
				R.drawable.images_2,	
				R.drawable.images_3,		    
				R.drawable.images_4,		     
				R.drawable.images_5,		   			
				R.drawable.images_6,		    
				R.drawable.images_7,
				R.drawable.images_8,		   
				R.drawable.images_9,
				R.drawable.images_10,		 
				R.drawable.images_11,		  
				R.drawable.images_12,		    
				R.drawable.images_13,
				R.drawable.images_14,
				R.drawable.images_15,
				R.drawable.images_16,
				R.drawable.images_17,  
				R.drawable.images_18,  
				R.drawable.images_19,
				R.drawable.images_20,
				R.drawable.images_21,
				R.drawable.images_22,
				R.drawable.images_23,
				R.drawable.images_24
		};

		public YidianListViewAdapter(Context context ,List<List<String>
		> lls,List<String> list1,List<String> list2,List<String> list3,List<Integer> list4,List<String> list5){
			this.mInflater = LayoutInflater.from(context);
			this.lls = lls;
			this.list1=list1;
			this.list2=list2;
			this.list3=list3;
			this.list4=list4;
			this.list5=list5;
		}
		public int getCount() {
			// TODO Auto-generated method stub
			return list1.size();
		}

		public Object getItem(int arg0) {
			// TODO Auto-generated method stub
			return arg0;
		}

		public long getItemId(int arg0) {
			// TODO Auto-generated method stub
			return arg0;
		}

		public View getView( final int position, View convertView, ViewGroup parent) {

			ViewHolder holder = null;
			if (convertView == null) {
				holder=new ViewHolder();  
				convertView = mInflater.inflate(R.layout.yidianlist, null);
				holder.img = (ImageView)convertView.findViewById(R.id.img);
				//				holder.title = (TextView)convertView.findViewById(R.id.title);	
				holder.tv1 = (TextView) convertView     
						.findViewById(R.id.textView1);  
				holder.tv2 = (TextView) convertView     
						.findViewById(R.id.textView2);    
				holder.tv3 = (TextView) convertView      
						.findViewById(R.id.textView3);  
				holder.tv4 = (TextView) convertView     
						.findViewById(R.id.textView4);
				holder.btn_diancai = (Button)convertView
						.findViewById(R.id.button1);
				convertView.setTag(holder);
			}else {

				holder = (ViewHolder)convertView.getTag();
			}
			holder.tv1.setText(lls.get(0).get(position));   
			holder.tv2.setText(lls.get(1).get(position));   
			holder.tv3.setText(lls.get(2).get(position)); 
			holder.tv4.setText(lls.get(3).get(position)); 
			holder.btn_diancai.setOnClickListener(new OnClickListener() {
				
				@Override
				public void onClick(View v) {
					// TODO Auto-generated method stub
					String databaseFilename = URL + "/" + DB_FILE_NAME;				
					db = SQLiteDatabase.openOrCreateDatabase(databaseFilename, null);
					String delete = "delete from insert_dish where Name = '"+lls.get(0).get(position)+"'";
					db.execSQL(delete);
					db.close();
					list1.remove(position);
					list2.remove(position);
					list3.remove(position);
					list4.remove(position);
					list5.remove(position);
					YidianListViewAdapter.this.notifyDataSetChanged();
				}
			});
			holder.img.setImageResource(mImageIds[list4.get(position)]);
			return convertView;
		}

		
	}

}