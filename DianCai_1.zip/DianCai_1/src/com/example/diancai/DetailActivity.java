package com.example.diancai;

public class DetailActivity {

}
